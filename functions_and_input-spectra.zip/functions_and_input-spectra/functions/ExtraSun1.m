function [Esun] = ExtraSun1(lam, wavelength, extra)
% Compute the Esun value at the desired wavelength 'lam'
% using linear interpolation with edge clamping.

% Case 1: lam is less than the smallest wavelength – clamp to first value
if lam <= wavelength(1)
    Esun = extra(1);
    return;
end

% Case 2: lam is greater than the largest wavelength – clamp to last value
if lam >= wavelength(end)
    Esun = extra(end);
    return;
end

% Case 3: Interpolation within range
for i = 2:length(wavelength)
    
    if lam == wavelength(i)
        % Exact match
        Esun = extra(i);
        return;
        
    elseif lam < wavelength(i)
        % Linear interpolation between i-1 and i
        slope = (extra(i) - extra(i-1)) / (wavelength(i) - wavelength(i-1));
        Esun = extra(i-1) + slope * (lam - wavelength(i-1));
        return;
    end
end
