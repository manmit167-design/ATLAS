function [a0, a1] = a0_a1_phytoplanc1(lam, lam_p, a0_p, a1_p)
% Computes absorption (a0) and scattering (a1) values at desired wavelength (lam)
% using linear interpolation from input arrays:
%   lam_p  = array of known wavelengths
%   a0_p   = corresponding absorption values
%   a1_p   = corresponding scattering values

% Handle case: below minimum wavelength
if lam <= lam_p(1)
    a0 = a0_p(1);
    a1 = a1_p(1);
    return;
end

% Handle case: above maximum wavelength
if lam >= lam_p(end)
    a0 = a0_p(end);
    a1 = a1_p(end);
    return;
end

% Interpolation within range
for i = 2:length(lam_p)
    if lam == lam_p(i)
        % Exact match
        a0 = a0_p(i);
        a1 = a1_p(i);
        return;
        
    elseif lam < lam_p(i)
        % Interpolate between lam_p(i-1) and lam_p(i)
        ma0 = (a0_p(i) - a0_p(i-1)) / (lam_p(i) - lam_p(i-1));
        ma1 = (a1_p(i) - a1_p(i-1)) / (lam_p(i) - lam_p(i-1));

        a0 = a0_p(i-1) + ma0 * (lam - lam_p(i-1));
        a1 = a1_p(i-1) + ma1 * (lam - lam_p(i-1));
        return;
    end
end
