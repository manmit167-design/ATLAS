function absorp_W_val = Absorp_W(lam, wavelength, absorpt_W)
% This function computes the absorption value at the desired wavelength lam
% via linear interpolation on the tabulated (wavelength, absorpt_W) pairs.

    % Ensure column vectors
    wavelength = wavelength(:);
    absorpt_W  = absorpt_W(:);

    % --- 1) Handle lam outside the tabulated range safely ---
    if lam <= wavelength(1)
        absorp_W_val = absorpt_W(1);
        return
    elseif lam >= wavelength(end)
        absorp_W_val = absorpt_W(end);
        return
    end

    % --- 2) Find interval [wavelength(i), wavelength(i+1)] that contains lam ---
    % wavelength(i) <= lam < wavelength(i+1)
    idx = find(wavelength <= lam, 1, 'last');   % guarantees 1 <= idx < end

    x1 = wavelength(idx);
    x2 = wavelength(idx+1);
    y1 = absorpt_W(idx);
    y2 = absorpt_W(idx+1);

    % --- 3) Linear interpolation ---
    absorp_W_val = y1 + (y2 - y1) * (lam - x1) / (x2 - x1);
end
